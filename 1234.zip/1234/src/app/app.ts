import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './components/header/header';
import { FooterComponent } from './components/footer/footer';
import { Logros } from './components/logros/logros';
import { Premios } from './components/premios/premios';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    HeaderComponent,
    FooterComponent,
    Logros,
    Premios,
  ],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent { }
