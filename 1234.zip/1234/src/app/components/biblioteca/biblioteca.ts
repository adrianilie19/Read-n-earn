import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Libro {
  id: number;
  titulo: string;
  autor: string;
  estado?: string;
  progreso?: number;
}

@Component({
  selector: 'app-biblioteca',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './biblioteca.html',
  styleUrls: ['./biblioteca.css']
})
export class Biblioteca {
  libros: Libro[] = [
    { id: 1, titulo: 'El señor de las moscas', autor: 'William Golding', estado: 'Por comenzar'},
    { id: 2, titulo: 'Cien años de soledad', autor: 'Gabriel García Márquez', estado: 'En progreso'},
    { id: 3, titulo: '1984', autor: 'George Orwell', estado: 'En progreso', progreso: 20 },
    { id: 4, titulo: 'Don Quijote de la Mancha', autor: 'Miguel de Cervantes', estado: 'Por comenzar'}
  ];

  agregarABiblioteca(libro: Libro) {
    console.log('Agregado a biblioteca:', libro.titulo);
  }
}
